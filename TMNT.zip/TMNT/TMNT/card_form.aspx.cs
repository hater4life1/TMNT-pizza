﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TMNT
{
    public partial class card_form : System.Web.UI.Page
    {
        
        Boolean checkcards;
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        private void validate_card()
        {
            checkcards = true;
            if(Ncard_tb.Text == "")
            {
                card_label.Text += "please enter your name</p>";
                checkcards = false;
            }
            if(cn_tb.Text == "")
            {
                card_label.Text += "please enter your card number</p>";
                checkcards = false;
            }
            if (ED_tb.Text == "")
            {
                card_label.Text += "please enter the expiray date on your card</p>";
                checkcards = false;
            }
            if (sc_tb.Text == "")
            {
                card_label.Text += "please enter the sercurity number on your card </p>";
                checkcards = false;
            }
           
        }

        protected void Done_card_Click(object sender, EventArgs e)
        {
            validate_card();
            if (checkcards ==true)
            {
                //save_card();
                Response.Redirect("done.aspx");

            }


        }

        //private void save_card()
        //{
        //    var card_details = new Card_info ();

        //    card_details.Name = Ncard_tb.Text;
        //    card_details.Card_number = cn_tb.Text;
        //    card_details.Expiary_date =ED_tb.Text;
        //    card_details.sercurity_code = sc_tb.Text;
           
          
        //    Random random = new Random();
        //    card_details.Id = random.Next(30000);
            

        //    customer_informationEntities3 database = new customer_informationEntities3();

        //    database.Card_info.Add(card_details);
        //    database.SaveChanges();""
        //}
    }
    
}
