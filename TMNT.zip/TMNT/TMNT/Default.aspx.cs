﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TMNT
{
    public partial class Default : System.Web.UI.Page
    {
        Boolean Check;
        decimal price = 0;

        protected void Page_Load(object sender, EventArgs e)
        {
           
            

        }

        protected void pizzacost()
        {
           

            if (pizza_size.SelectedItem.Text == "Small(12 inch-£12)")
            {
                price += 12;

            }
            if (pizza_size.SelectedItem.Text == "Medium(14 inch-£14)")
            {
                price += 14;

            }
            if (pizza_size.SelectedItem.Text == "Large(16 inch-£16)")
            {
                price += 16;

            }
            if (pizza_crust.SelectedItem.Text == "Thick(+£2)")
            {
                price += 2;

            }

            if (s_check.Checked)
            {
                price += 2;
            }

            if (p_checkbox.Checked)
            {
                price += 1.50m;
            }


            if (o_check.Checked)
            {
                price += 1;
            }
            if (gp_check.Checked)
            {
                price += 1;
            }


            cost_label.Text = price.ToString();
          
        }

        protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            pizzacost();
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            pizzacost();
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            pizzacost();
        }

        protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            pizzacost();

        }

        protected void o_check_CheckedChanged(object sender, EventArgs e)
        {
            pizzacost();
        }

        protected void gp_check_CheckedChanged(object sender, EventArgs e)
        {
            pizzacost();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            cost_label.Text= "";
            

            validate_page();
            if (Check == true)
            {
                save_data();
                pizzacost();
                Response.Redirect("done.aspx");
                
            }


            //use for credit
            // Response.Redirect("Done.aspx");
        }

        private void validate_page()
        {
            Check = true;

            if (name_tb.Text=="")
            {
                cost_label.Text += "please enter your name</p>";
                Check = false;
            }
            if (address_tb.Text=="")
            {
                cost_label.Text += "please enter your address</p>";
                Check = false;
            }
            if(town_tb.Text == "")
            {
                cost_label.Text += "please enter your town</p>";
                Check = false;
            }
            if(post_code_tb.Text == "")
            {
                cost_label.Text += "please enter your post code</p>";
                Check = false;
            }
            if(phone_tb.Text == "")
            {
                cost_label.Text += "please enter your phone</p>";
                Check = false;
            }
            if ( pizza_size.Text== "please select a pizza size")
            {
                cost_label.Text += "please select a pizza size</p>";
                Check = false;
            }
            if (pizza_crust.Text == "please select a crust")
            {
                cost_label.Text += "please select a crust</p>";
                Check = false;
            }
            if (payment_methods.SelectedIndex != 0 && payment_methods.SelectedIndex != 1)
            {
                cost_label.Text += "please select a payment method</p>";
                Check = false;
            }


    }

        private void save_data()
        {
            var order = new Customer_database();

            order.Name = name_tb.Text;
            order.pizza_size = pizza_size.Text;
            order.crust = pizza_crust.Text;
            order.phone_number = phone_tb.Text;
            order.Address = address_tb.Text;
            order.Town = town_tb.Text;
            order.Post_code = post_code_tb.Text;
            Random random = new Random();
            order.Id = random.Next(30000);
            order.Cost = price;

            customer_informationEntities3 database = new customer_informationEntities3();

            database.Customer_databases.Add(order);
            database.SaveChanges();
        }

        protected void p_checkbox_CheckedChanged(object sender, EventArgs e)
        {

            pizzacost();
           
        }
    }
}